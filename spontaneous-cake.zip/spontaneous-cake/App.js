import * as React from 'react';
import { Text, TextInput, View, Button, Image } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';

function HomeScreen({ navigation, route }) {
  React.useEffect(() => {
    if (route.params?.post) {
      // Post updated, do something with `route.params.post`
      // For example, send the post to the server
    }
  }, [route.params?.post]);

  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor:'green' }}>
     <Image
     style={{ marginRight:20 }}
        source={require('./xbox.jfif')}
      />
    <Text style={{ fontSize: 30,fontWeight: 'normal', textAlign: 'center',color: '#ffff',marginBottom:100,}}>
       Bem-vindo(a) ao Suporte do Xbox
      </Text>
    
      <View style={{backgroundColor: "#fff",padding:3,width:280,borderRadius:15, marginBottom:20}}>
      <Button
        title="Reclame Aqui"
        onPress={() => navigation.navigate('CreatePost')}
      /></View>
      <View style={{backgroundColor: "#fff",padding:10,width:270,borderRadius:25}}>
      <Text style={{ margin: 10 }}>Reclamações:</Text>
      <Text style={{ margin: 10 }}>Jogo ta bugado</Text> 
      <Text style={{ margin: 10 }}>Não to conseguindo logar</Text> 
      <Text style={{ margin: 10 }}>outros</Text>
    </View>
    </View>
  );
}

function CreatePostScreen({ navigation, route }) {
  const [postText, setPostText] = React.useState('');

  return (
    <>
      <TextInput
        multiline
        placeholder="Faça sua reclamação"
        style={{ height: 200, padding: 10, backgroundColor: '#ffff' }}
        value={postText}
        onChangeText={setPostText}
      />
      <Button
        title="Done"
        onPress={() => {
          navigation.navigate('Home', { post: postText });
        }}
      />
    </>
  );
}

const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator mode="modal">
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="CreatePost" component={CreatePostScreen} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
